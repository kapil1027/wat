//requires

const port = process.env.PORT || 3000;
var fs = require('fs');
var https = require('https');
var express = require('express');
var app = express();
var options = {
    key: fs.readFileSync('key.pem'),
    cert: fs.readFileSync('cert.pem')
};
var serverPort = port;
var server = https.Server(options, app);
var io = require('socket.io')(server);

let broadcasters = {};

// express routing
app.use(express.static("public"));

// signaling
io.on("connection", function (socket) {
    console.log("a user connected");


  socket.on("send_message", function (user) {
      console.log("message by", user);
      socket.in(user.room).emit("recieved_msg",user);
  });


  socket.on("register as broadcaster", function (room) {
    console.log("register as broadcaster for room", room);

    broadcasters[room] = socket.id;
    
    socket.join(room);
  });

  socket.on("register as viewer", function (user) {
    console.log("register as viewer for room", user.room);

    socket.join(user.room);
    user.id = socket.id;

    socket.to(broadcasters[user.room]).emit("new viewer", user);
  });

  socket.on("candidate", function (id, event) {
    socket.to(id).emit("candidate", socket.id, event);
  });

  socket.on("offer", function (id, event) {
    event.broadcaster.id = socket.id;
    socket.to(id).emit("offer", event.broadcaster, event.sdp);
  });

  socket.on("answer", function (event) {
    socket.to(broadcasters[event.room]).emit("answer", socket.id, event.sdp);
  });
});

// listener
server.listen(serverPort, function () {
    console.log('server up and running at %s port', serverPort);
});

