from django.urls import path
from . import views
urlpatterns = [
    path('',views.index,name='index'),
    path('delete/<city_name>/',views.delete_city,name='delete_city'),
    path('tables/',views.tables, name='tables'),
    path('deletet/<city_namet>/',views.delete_cityt,name='del_city'),
    path('weather_forcast/',views.weather_forcast,name='weather_forcast'),
    path('geotest/',views.geotest,name='geotest'),

    
]