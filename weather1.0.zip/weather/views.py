import requests
from django.shortcuts import render,redirect
from .models import City,CityT
from .forms import CityForm,CityFormT
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.contrib import messages

from datetime import datetime


def index(request):
    url = 'https://api.openweathermap.org/data/2.5/weather?q={}&units=metric&appid=09414554775218e59c1f5304225df4d4'
    message=''
    message_class=''
    err_msg=''
    record_count = City.objects.count()
    if request.method == 'POST':
        form = CityForm(request.POST)
        if form.is_valid():
            new_city = form.cleaned_data['name']
            existing_city_count = City.objects.filter(name=new_city).count()
            if existing_city_count==0:
                if record_count < 6 :
                    r = requests.get(url.format(new_city)).json()
                    print(r)
                    if r['cod']==200:
                        form.save()
                    else:
                        err_msg='city does not exist'
                else :
                    err_msg = "You can not add more than 6 cities"
            else:
                err_msg="city already exist"
        if err_msg:
            message = err_msg
            message_class = 'danger'
        else:
            message = 'City added successfully!'
            message_class = 'success'
    form = CityForm()

    cities=City.objects.all()
    weather_data=[]
    labels = []
    data = []
    for city in cities:
        r=requests.get(url.format(city)).json()
        city_weather = {
            'city' : city.name,
            'temperature' : r['main']['temp'],
            'description' : r['weather'][0]['description'],
            'icon' : r['weather'][0]['icon']

        }
        labels.append(city.name)
        data.append(r['main']['temp'])
        weather_data.append(city_weather)
        max_temp = max(data)
        min_temp = min(data)

    context={ 
            'weather_data': weather_data,'form':form,'labels':labels,'data':data,
            'max_temp':max_temp,'min_temp':min_temp,
            'message': message,
            'message_class': message_class,
            }
    return render(request, 'weather/weather.html',context)

def delete_city(request, city_name):
    City.objects.get(name=city_name).delete()
    return redirect('index')

def tables(request) :
    import datetime
    cities = CityT.objects.all() 

    url = 'https://api.openweathermap.org/data/2.5/weather?q={}&units=metric&appid=09414554775218e59c1f5304225df4d4'
    message=''
    message_class=''
    err_msg=''
    weather_data = [] 
    if request.method == 'POST':
        form = CityFormT(request.POST)
        if form.is_valid():
            new_city = form.cleaned_data['name']
            existing_city_count = CityT.objects.filter(name=new_city).count()
            if existing_city_count==0:
                r = requests.get(url.format(new_city)).json()
                print(r)
                if r['cod']==200:
                    form.save()
                else:
                    err_msg='city does not exist'
            else:
                err_msg="city already exist"
        if err_msg:
            message = err_msg
            message_class = 'danger'
        else:
            message = 'City added successfully!'
            message_class = 'success' 

    form = CityFormT()
    for city in cities:
        r=requests.get(url.format(city)).json()
        date = datetime.date.today()
        city_weather = {
            'date' : date,
            'city' : city.name,
            'temperature' : r['main']['temp'],
            'pressure' : r['main']['pressure'],
            'humidity' : r['main']['humidity'],
            'description' : r['weather'][0]['description'],
            'wind' : r['wind']['speed'],
            'icon' : r['weather'][0]['icon']

        }
        weather_data.append(city_weather)

########################### PAGINATION #########################################
    # page = request.GET.get('page', 1)

    # paginator = Paginator(cities, 3)
    # try:
    #     users = paginator.page(page)
    # except PageNotAnInteger:
    #     users = paginator.page(1)
    # except EmptyPage:
    #     users = paginator.page(paginator.num_pages)
##############################################################################    

    context = {
            'weather_data' : weather_data,
            'form' : form,
            'message': message,
            'message_class': message_class,
        }

    return render(request,'weather/tables.html',context)

def delete_cityt(request,city_namet) :
    city = CityT.objects.get(name=city_namet).delete()
    return redirect('tables')


def weather_forcast(request):
    url = 'https://api.openweathermap.org/data/2.5/weather?q={},in,&units=metric&APPID=610be106b09e80043ed08dcf803b09e1'

    url1 = 'https://api.openweathermap.org/data/2.5/onecall?lat={}&lon={}&units=metric&exclude=current,minutely,hourly&appid=610be106b09e80043ed08dcf803b09e1'

    if request.method == 'POST':


        daily_data=[]
        new_city = request.POST.get('city1')
        print(new_city)

        r = requests.get(url.format(new_city)).json()

        if r['cod']==200:
            lat=r['coord']['lat']
            lon=r['coord']['lon']
            r1 = requests.get(url1.format(lat,lon)).json()
            days=len(r1['daily'])

            for x in r1['daily']:
                data_time = timestamp(x['dt'])

                data = {
                    'date' : data_time['date'],
                    'time' : data_time['time'],
                    'description' : x['weather'][0]['description'],
                    'icon' : x['weather'][0]['icon'],
                    'min_temp' : x['temp']['min'],
                    'max_temp' : x['temp']['max'],
                    'speed' : x['wind_speed'],
                    'humidity' : x['humidity'],
                    'pressure' : x['pressure']
                }

                #print(data)

                daily_data.append(data)


        if r['cod']==200:
            city_weather = {
                'name' : r['name'],
                'temperature' : r['main']['temp'],
                'country' : r['sys']['country'],
                'description' : r['weather'][0]['description'],
                'icon' : r['weather'][0]['icon'],
                'max_temp' : r['main']['temp_max'],
                'min_temp' : r['main']['temp_min'],
                'wind' : r['wind']['speed'],
                'humidity' : r['main']['humidity'],
                'pressure' : r['main']['pressure']
            }

            #print(city_weather)

            messages.success(request,"City Found...")

            content = {'city_weather' : city_weather,'daily_data':daily_data,'days':days}

            return render(request,'weather/weather_f.html',content)
        else:
            messages.error(request,"City not Found...")
            return redirect('index')
    else:
        return render(request,'weather/weather_f.html')


def timestamp(x):
    dt_object = datetime.fromtimestamp(x)
    time = dt_object.strftime("%H:%M")
    date = dt_object.strftime("%d/%m/%Y")
    date_time ={'date':date,'time':time}
    return date_time


def geotest(request):
    if request.method == "POST":
        daily_data=[]
        lat=request.POST.get('lat')
        lon=request.POST.get('lon')
        print(lat,lon)
        url1 = 'https://api.openweathermap.org/data/2.5/weather?lat={}&lon={}&units=metric&appid=610be106b09e80043ed08dcf803b09e1'
        url2 = 'https://api.openweathermap.org/data/2.5/onecall?lat={}&lon={}&units=metric&exclude=current,minutely,hourly&appid=610be106b09e80043ed08dcf803b09e1'
        r = requests.get(url1.format(lat, lon)).json()

        #print(r)

        # city=lat+","+lon
        # city=str(city)
        # city_detalis=get_city_name(city)


        if r['cod']==200:
            r1 = requests.get(url2.format(lat,lon)).json()
            days=len(r1['daily'])

            for x in r1['daily']:
                data_time = timestamp(x['dt'])

                data = {
                    'date' : data_time['date'],
                    'time' : data_time['time'],
                    'description' : x['weather'][0]['description'],
                    'icon' : x['weather'][0]['icon'],
                    'min_temp' : x['temp']['min'],
                    'max_temp' : x['temp']['max'],
                    'speed' : x['wind_speed'],
                    'humidity' : x['humidity'],
                    'pressure' : x['pressure']
                }

                #print(data)

                daily_data.append(data)

        if r['cod'] == 200:
            city_weather = {
                'name': r['name'],
                'temperature': r['main']['temp'],
                'country': r['sys']['country'],
                'description': r['weather'][0]['description'],
                'icon': r['weather'][0]['icon'],
                'max_temp': r['main']['temp_max'],
                'min_temp': r['main']['temp_min'],
                'wind': r['wind']['speed'],
                'humidity': r['main']['humidity'],
                'pressure': r['main']['pressure']
            }

            content = {'city_weather': city_weather, 'daily_data': daily_data, 'days': days}

            messages.success(request,"Your Location was Found...")

            return render(request, 'weather/weather_f.html', content)
        else:
            messages.error(request,"Your Location was not Found...")
            return redirect('index')

    else:
        return redirect('index')

