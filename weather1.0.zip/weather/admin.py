from django.contrib import admin
from .models import City,CityT
admin.site.register(City)
admin.site.register(CityT)